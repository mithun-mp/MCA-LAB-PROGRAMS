<?php
session_start();
if(!isset($_SESSION['username'])){
    header("Location:login.php");
    exit();
}
?>
<DOCTYPE html>
    <html>
        <body>
            <h2>Welcome page</h2>
            <P>Welcome,<?php echo $_SESSION['username'];?>!</p>
            <a href="logout.php">logout</a>
</body>
</html>