<?php
session_start();
$servername="localhost";
$username="root";
$password="";
$dbname="userdb";
$conn=mysqli_connect($servername,$username,$password,$dbname);
$conn=mysqli_connect("localhost","root","","userdb");
if(!$conn){
    die("connection failed: ".mysqli_connect_error());
}
//if(isset($_POST['login'])){
    $user=$_POST['username'];
    $pass=$_POST['password'];
    echo "User". $user;
    $sql="SELECT * FROM users WHERE username='$user'";
    echo "Query". $sql;
    $result=mysqli_query($conn,$sql);
    echo "Count". mysqli_num_rows($result);
    $row=mysqli_fetch_assoc($result);
    
    if($row){
        echo $row['password'];
        echo $user;
        if($row['password']==$pass){

            $_SESSION['username']==$user;
            echo"login successfull welcome back $user";
            header("Location:welcome.php");
        }else{
            echo"Incorrect password";
        }
        }else{
            echo"Incorrect username";
        }
    
//}
?>
<!DOCTYPE html>
<html>
    <body>
        <h2>Login Form</h2>
        <form method="post" action="">
            username:<input type="text" name="username"><br>
            password:<input type="password" name="password"><br>
            <input type="submit" name="login" value="login">
        </form>
</body>
</html>
