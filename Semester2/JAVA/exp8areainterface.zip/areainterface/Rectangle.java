package areainterface;


public class Rectangle implements Shape {
    double length, breadth;

    Rectangle(double length, double breadth) {
        this.length = length;
        this.breadth = breadth;
    }

    public void area() {
        double a = length * breadth;
        System.out.println("Area of Rectangle: " + a);
    }

    public void perimeter() {
        double p = 2 * (length + breadth);
        System.out.println("Perimeter of Rectangle: " + p);
    }
}
