package areainterface;

public interface Shape {
    void area();
    void perimeter();
}

