import java.util.Scanner;

public class Instructor extends Employee {
    private String department;
    private String subjectTaught;

    public Instructor(int id, String name, double salary, String address,
                      String department, String subjectTaught) {
        super(id, name, salary, address);
        this.department = department;
        this.subjectTaught = subjectTaught;
    }

    public Instructor() {
        super();
        this.department = "";
        this.subjectTaught = "";
    }

    public void inputData(Scanner sc) {
        System.out.print("Enter Employee ID: ");
        id = sc.nextInt();
        sc.nextLine();

        System.out.print("Enter Name: ");
        name = sc.nextLine();

        System.out.print("Enter Salary: ");
        salary = sc.nextDouble();
        sc.nextLine();

        System.out.print("Enter Address: ");
        address = sc.nextLine();

        System.out.print("Enter Department: ");
        department = sc.nextLine();

        System.out.print("Enter Subject Taught: ");
        subjectTaught = sc.nextLine();
    }

    public void display() {
        System.out.println("\nInstructor Details:");
        System.out.println("----------------------------");
        System.out.println("ID: " + id);
        System.out.println("Name: " + name);
        System.out.println("Salary: " + salary);
        System.out.println("Address: " + address);
        System.out.println("Department: " + department);
        System.out.println("Subject Taught: " + subjectTaught);
    }
}
