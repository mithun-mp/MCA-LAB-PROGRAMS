import java.util.Scanner;

public class MainClass {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of instructors: ");
        int n = sc.nextInt();
        sc.nextLine();

        Instructor[] instructors = new Instructor[n];

        for (int i = 0; i < n; i++) {
            System.out.println("\nEnter details for Instructor " + (i + 1) + ":");
            instructors[i] = new Instructor();
            instructors[i].inputData(sc);
        }

        System.out.println("\nDisplaying Instructor Details:");
        for (int i = 0; i < n; i++) {
            instructors[i].display();
        }

        sc.close();
    }
}
