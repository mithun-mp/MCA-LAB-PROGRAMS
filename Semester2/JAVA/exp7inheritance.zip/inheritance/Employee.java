public class Employee {
    protected int id;
    protected String name;
    protected double salary;
    protected String address;

    public Employee(int id, String name, double salary, String address) {
        this.id = id;
        this.name = name;
        this.salary = salary;
        this.address = address;
    }

    public Employee() {
        this.id = 0;
        this.name = "";
        this.salary = 0.0;
        this.address = "";
    }
}
        